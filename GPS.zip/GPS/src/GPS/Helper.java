/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package GPS;

import java.util.ArrayList;
/**
l'interet de cette classe est au lieu de achaque algorithme on declarent le probleme
 le path cost la listes des explorees
 */
public abstract class Helper {

    public Problem probleme;
    public double coutOptimale;
    protected ArrayList<Noeuds> exploree;

    public abstract Noeuds Helpper();


    public Helper(Problem probleme) {
        super();
        this.probleme = probleme;
        this.coutOptimale = 0.0;
        this.exploree = new ArrayList<>();
    }


}
