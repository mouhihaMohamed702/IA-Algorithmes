/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package GPS;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Vector;

public class Problem {

	private Etat EtatInitiale;
	private ArrayList<action> actions;
	// initialiser le probleme
	public Problem(Etat EtatInitiale, ArrayList<action> actions) {
		super();
		this.setEtatInitiale(EtatInitiale);
		this.setActions(actions);
	}


	public Etat getEtatInitiale() {
		return EtatInitiale;
	}


	public void setEtatInitiale(Etat etatInitiale) {
		this.EtatInitiale = etatInitiale;
	}


	public ArrayList<action> getActions() {
		return actions;
	}


	public void setActions(ArrayList<action> actions) {
		this.actions = actions;
	}
	
	
	
	public static ArrayList<Etat> solution(Noeuds resultat){
        if (resultat == null)
            return new ArrayList<>();
		ArrayList<Etat> resulte = new ArrayList<>();
        resulte.add(resultat.getState());
        Noeuds p = resultat.getParent();
        while (p != null) {
            resulte.add(p.getState());
            p = p.getParent();
        }
		System.out.println(resulte);
        Collections.reverse(resulte);
        return resulte;

	
	}


	public double heuristic(Etat etat) {
		return 0;
	}
	
	
}