/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package GPS;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;

public class UCSalgorithme extends Helper {

	
	public PriorityQueue<Noeuds> front;
	
	public UCSalgorithme(Problem probleme) {
		super(probleme);
        this.front = new PriorityQueue<>(Comparator.comparingDouble(Noeuds::getPathCost));

	}

	@Override
	public Noeuds Helpper() {
		
		this.front.add(new Noeuds(null, probleme.getEtatInitiale(),null,0));
		Visualisation visualisation = Visualisation.getInstance();
		visualisation.graphView.display();
		this.exploree = new ArrayList<>();
		this.coutOptimale = 0.0;
		
		while(true) {
			
			if(this.front.isEmpty()) {
				return null;
			}
			Noeuds noeuds = this.front.poll();
			if(noeuds.getState().testBut()){
				Visualisation.getInstance().coloratePath(noeuds);
				return noeuds;
			}
			this.exploree.add(noeuds);
			for(GPS.action action : this.probleme.getActions()) {
				Noeuds NoeudFils;
				Etat childEtat = noeuds.getState().Successeur(action);
				if (childEtat != null) {
					NoeudFils = new Noeuds(noeuds, childEtat, action, noeuds.getPathCost() + action.getCout());
					visualisation.addEdge(noeuds, NoeudFils, action);
					if (!this.front.contains(NoeudFils) || !this.exploree.contains(NoeudFils)) {
						this.front.add(NoeudFils);
					} else if (this.front.contains(NoeudFils)) {
						this.front.add(NoeudFils);
						this.front.removeIf(o -> {
							Noeuds noeud = (Noeuds) o;
							return noeud.equals(NoeudFils) && noeud.getPathCost() > NoeudFils.getPathCost();
						});		
					}		
				}
			}						
		}
		
	}
}
