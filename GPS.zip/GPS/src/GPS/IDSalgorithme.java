
/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package GPS;

import java.util.Stack;

public class IDSalgorithme extends Helper {
    public Stack<Noeuds> front;
	public IDSalgorithme(Problem problem) {
		super(problem);
		this.front = new Stack<Noeuds>();
	}
	@Override
	public Noeuds Helpper() {
		this.front.add(new Noeuds(null, probleme.getEtatInitiale(),null,0));
		Visualisation visualisation = Visualisation.getInstance();
		visualisation.graphView.display();
		while(!this.front.isEmpty()) {
			Noeuds noeuds = front.pop();
			
			if(noeuds.getState().testBut()){
				Visualisation.getInstance().coloratePath(noeuds);
				return noeuds;
			}
            
			this.exploree.add(noeuds);
			for(GPS.action action : this.probleme.getActions()) {
				Noeuds NoeudFils;
				Etat childEtat = noeuds.getState().Successeur(action);
				
				if (childEtat != null) {
					NoeudFils = new Noeuds(noeuds, childEtat, action, noeuds.getPathCost() + action.getCout());
					visualisation.addEdge(noeuds, NoeudFils, action);
					if (!this.front.contains(NoeudFils) && !this.exploree.contains(NoeudFils)) {
						this.front.push(NoeudFils);
						}
				}
				
			}

		}
		return null;
	}

	
	
	
	
	
	
	
	
	
}