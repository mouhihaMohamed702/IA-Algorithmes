/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package GPS;

import org.graphstream.graph.Edge;
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;

public class Visualisation {
    public Graph graphView;
    //delee d'affichage des noeuds
    public static int dele = 700;
    // pour design pattern singleton
    private static Visualisation instance;

    private Visualisation() {
        System.setProperty("org.graphstream.ui", "swing");

        this.graphView = new SingleGraph("Problem de recherche", false, true);
        this.graphView.setAttribute("ui.stylesheet", "url(file://" + Visualisation.class.getResource("GraphStyle.css").getFile() + ")");
    }

    public static Visualisation getInstance() {
        if (instance == null)
            instance = new Visualisation();
        return instance;
    }

    public void addEdge(Noeuds NoeudsSource, Noeuds NoeudsDistinataire, action action) {
        String idSource = NoeudsSource.getState().toString();
        String idDestinataire = NoeudsDistinataire.getState().toString();
        Edge edge = this.graphView.addEdge(idSource + "-" + idDestinataire, idSource, idDestinataire, true);
        edge.getNode0().setAttribute("ui.label", idSource);
        edge.getNode1().setAttribute("ui.label", idDestinataire);
        edge.setAttribute("ui.label", action.getnAction());

        try {
            Thread.sleep(dele);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void coloratePath(Noeuds solution) {
        this.graphView.getNode(solution.getState().toString()).setAttribute("ui.class", "sol");

        do {
            solution = solution.getParent();
            this.graphView.getNode(solution.getState().toString()).setAttribute("ui.class", "inSolu");
        } while (solution.getParent() != null);
        this.graphView.getNode(solution.getState().toString()).setAttribute("ui.class", "start");

    }

}
