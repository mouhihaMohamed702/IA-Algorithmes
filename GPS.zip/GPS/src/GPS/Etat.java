/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package GPS;

public abstract class Etat {
	// tester la possibiliter de faire une action
	protected abstract boolean testValide();
	// fonction pour tester le but retourne un valeur boolean
	protected abstract boolean testBut();
	// la fonction seccesseur
	protected abstract Etat Successeur(action action);
	

	

}
