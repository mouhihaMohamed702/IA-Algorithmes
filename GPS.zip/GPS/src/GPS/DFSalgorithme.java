/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package GPS;

import java.util.ArrayList;
import java.util.Stack;

public class DFSalgorithme extends Helper {

    protected Stack<Noeuds> front;

    public DFSalgorithme(Problem problem) {
        super(problem);
        this.front = new Stack<>();
    }

    public Noeuds Helpper() {
        Noeuds noeud = new Noeuds(null, this.probleme.getEtatInitiale(), null, 0.0);
        Visualisation visualisation = Visualisation.getInstance();
        visualisation.graphView.display();
        this.coutOptimale = 0.0;
        if (noeud.getState().testBut()) return noeud;
        // stack = pile
        this.front = new Stack<>();
        this.front.push(noeud);
        this.exploree = new ArrayList<>();

        while (true) {
            if (this.front.isEmpty()) return null;
            noeud = this.front.pop();
            exploree.add(noeud);
            Noeuds filsNoeud;
            Etat etatfils;

            for (GPS.action action : this.probleme.getActions()) {
                etatfils = noeud.getState().Successeur(action);
                if (etatfils != null) {
                    filsNoeud = new Noeuds(noeud, etatfils, action, noeud.getPathCost() + action.getCout());
                    if (!this.front.contains(filsNoeud) && !this.exploree.contains(filsNoeud)) {
                        visualisation.addEdge(noeud, filsNoeud, action);
                        if (etatfils.testBut()) {
                            Visualisation.getInstance().coloratePath(filsNoeud);
                            return filsNoeud;
                        }

                        this.front.add(filsNoeud);
                    }
                }
            }
        }
    }
}
