/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package GPS;

import java.util.Objects;

public class Noeuds {

    private Noeuds parent;
    private Etat etat;
    private GPS.action action;
    private double pathCost;


    public Noeuds(Noeuds parent, Etat etat, GPS.action action, double pathCost) {
        super();
        this.parent = parent;
        this.etat = etat;
        this.action = action;
        this.pathCost = pathCost;
    }


    public Noeuds getParent() {
        return parent;
    }


    public void setParent(Noeuds parent) {
        this.parent = parent;
    }


    public Etat getState() {
        return etat;
    }


    public void setState(Etat etat) {
        this.etat = etat;
    }


    public GPS.action getAction() {
        return action;
    }


    public void setAction(GPS.action action) {
        this.action = action;
    }


    public double getPathCost() {
        return pathCost;
    }


    public void setPathCost(double pathCost) {
        this.pathCost = pathCost;
    }


    @Override
    public int hashCode() {
        return Objects.hash(action, parent, pathCost, etat);
    }


    @Override
    public boolean equals(Object obj) {
        Noeuds dst = (Noeuds) obj;
        return dst.getState().equals(this.etat);
    }


    public int getDepth() {
        // depht
        int d = 0;
        if (parent == null) {
            return d;
        }
        Noeuds p = parent;
        while (parent != null) {
            d++;
            p = p.getParent();
        }

        return d;

    }
}
