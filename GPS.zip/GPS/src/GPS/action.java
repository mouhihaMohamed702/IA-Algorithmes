/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package GPS;

public class action {
// cout de l'action
	protected double cout;
	// le nom de l'action
	protected String nAction;

	public action(double cout, String nAction) {
		super();
		this.cout = cout;
		this.nAction = nAction;
	}

	public action(double cout) {
		super();
		this.cout = cout;
		this.nAction = "";
	}

	public String getnAction() {
		return nAction;
	}


	public void setnAction(String nAction) {
		this.nAction = nAction;
	}

	public double getCout() {
		return cout;
	}
	public void setCout(double cout) {

		this.cout = cout;
	}

	
	
}
