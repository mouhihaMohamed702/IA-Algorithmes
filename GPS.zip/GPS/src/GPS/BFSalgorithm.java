/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package GPS;

import java.util.Vector;

public class BFSalgorithm extends Helper {

    public Vector<Noeuds> front;

    public BFSalgorithm(Problem problem) {
        super(problem);
        this.front = new Vector<Noeuds>();
    }

    @Override
    public Noeuds Helpper() {

        this.front.add(new Noeuds(null, probleme.getEtatInitiale(), null, 0));
//
        Visualisation visualisation = Visualisation.getInstance();
        visualisation.graphView.display();

        while (!this.front.isEmpty()) {

            Noeuds noeuds = this.front.firstElement();
            this.front.removeElementAt(0);

            if (noeuds.getState().testBut()) {
                Visualisation.getInstance().coloratePath(noeuds);
                return noeuds;
            }

            this.exploree.add(noeuds);

            for (GPS.action action : this.probleme.getActions()) {

                Noeuds childNoeuds;
                Etat childEtat = noeuds.getState().Successeur(action);

                if (childEtat != null) {
                    childNoeuds = new Noeuds(noeuds, childEtat, action, noeuds.getPathCost() + action.getCout());

                    visualisation.addEdge(noeuds, childNoeuds, action);

                    if (!this.front.contains(childNoeuds) && !this.exploree.contains(childNoeuds)) {
                        this.front.add(childNoeuds);
                    }
                }
            }
        }

        return null;
    }
}