/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package GPS;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.function.Function;

public class AstarAlgorithme extends Helper {

    public PriorityQueue<Noeuds> front;

    // la fonction heuristique
    public Function<Noeuds, Double> heuristicFunction;

    public AstarAlgorithme(Problem problem) {
        super(problem);
        front = new PriorityQueue<>(Comparator.comparingDouble(this.heuristicFunction::apply));
        this.heuristicFunction = nodes -> 0.0;
    }

    @Override
    public Noeuds Helpper() {
        this.front.add(new Noeuds(null, probleme.getEtatInitiale(), null, 0));
        Noeuds noeuds = this.front.remove();
        if (noeuds.getState().testBut()) return noeuds;
        this.exploree.add(noeuds);

        for (GPS.action action : this.probleme.getActions()) {
            Noeuds childNoeuds;
            Etat childEtat = noeuds.getState().Successeur(action);

            if (childEtat != null) {
                childNoeuds = new Noeuds(noeuds, childEtat, action, noeuds.getPathCost() + action.getCout());

                if (!this.front.contains(childNoeuds) || !this.exploree.contains(childNoeuds))
                    this.front.add(childNoeuds);
            }

        }

        return null;
    }


}
