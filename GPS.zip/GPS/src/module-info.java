/**
 * 
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
module GPS_IA {
	requires java.xml;
    requires gs.core;
}