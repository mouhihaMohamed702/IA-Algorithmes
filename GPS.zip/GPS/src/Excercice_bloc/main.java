/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package Excercice_bloc;

import java.util.ArrayList;

import GPS.*;

public class main {

	public static void main(String[] args) {
// initial state block1
		state EtatInitiale = new state(1);
		//actions arraylist
		ArrayList<action> Action = new ArrayList<>();
		// define the 2 possible actions
		Action.add(new action(1,"walk"));
		Action.add(new action(2,"tram"));
	// instance the probleme with initial state and action
		Problem problem = new Problem(EtatInitiale, Action);
		//instance of usc algorithme take the probleme as its input
		UCSalgorithme ucs = new UCSalgorithme(problem);
		// ucs helpper is a class that resume que achque fois en declare path ....
		Noeuds noeuds = ucs.Helpper();
		
		System.out.println((noeuds != null ? Problem.solution(noeuds) + " Cost: " +  noeuds.getPathCost() + " " : "Vide"));
	}

}
