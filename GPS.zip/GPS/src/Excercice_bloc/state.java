package Excercice_bloc;

import GPS.action;
import GPS.Etat;

public class state extends Etat {

	public int block;

	public state(int block) {
		super();
		this.block = block;
	}
	
// la redifinition de la fonction seccesseur qui existe dans la classe abstract Etat
	@Override
	protected Etat Successeur(action action) {
		state s;
		
		switch(action.getnAction()) {
		
		case "walk":
			s = new Excercice_bloc.state(block +1);
			if(s.testValide()) return s;
			break;
		
		case "tram":
			s = new Excercice_bloc.state(block *2);
			if(s.testValide()) return s;
			break;
		}
		
		return null;
	}

	@Override
	protected boolean testBut() {
		if(block == 10) {
			return true;
		}
		return false;
	}

	@Override
	protected boolean testValide() {
		if(block >0) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return "[block=" + block + "]";
	}
	
	
}
