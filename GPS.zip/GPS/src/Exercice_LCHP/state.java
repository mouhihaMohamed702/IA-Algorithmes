/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package Exercice_LCHP;

import java.util.Arrays;
import java.util.Objects;

import GPS.action;
import GPS.Etat;

public class state extends Etat {
// cote initale
	private String RvA;
	// cote goal
	private String RvB;
	
	
	
	public state(String RvA, String RvB) {
		super();
		this.RvA = RvA;
		this.RvB = RvB;
	}
	
	public String getRvA() {
		return RvA;
	}

	public void setRvA(String rvA) {
		this.RvA = rvA;
	}

	public String getRvB() {
		return RvB;
	}

	public void setRvB(String rvB) {
		this.RvB = rvB;
	}




	@Override
	protected Etat Successeur(action action) {
		String AResult = "";
		String BResult = "";
		switch (action.getnAction()) {
			case "P<-":
				BResult = this.RvB.replace("P", "");
				AResult = this.RvA + "P";
				break;
			case "PL->":
				AResult = this.RvA.replaceAll("P|L", "");
				BResult = this.RvB + "PL";
				break;
			case "PL<-":
				BResult = this.RvB.replaceAll("P|L", "");
				AResult = this.RvA + "PL";
				break;
			case "PC->":
				AResult = this.RvA.replaceAll("P|C", "");
				BResult = this.RvB + "PC";
				break;
			case "PC<-":
				BResult = this.RvB.replaceAll("P|C", "");
				AResult = this.RvA + "PC";
				break;
			case "PH->":
				AResult = this.RvA.replaceAll("P|H", "");
				BResult = this.RvB + "PH";
				break;
			case "PH<":
				BResult = this.RvB.replaceAll("P|H", "");
				AResult = this.RvA + "PH";
				break;
			default:
				return null;
		}
		state tmp = new state(AResult, BResult);
		if (tmp.testValide()) {
			return tmp;
		}
		return null;
		
	}

	@Override
	protected boolean testBut() {
		return Arrays.stream("PLCH".split("")).allMatch(this.RvB::contains) && (this.RvA.length() == 0);

	}

	@Override
	protected boolean testValide() {
		String tmp = this.RvA + this.RvB;
		// check if data contains all
		if (!Arrays.stream("PLCH".split("")).allMatch(tmp::contains) || (tmp.length() != 4)) return false;
		
		// check if L & C are in same place without P
		// in RvA
		if (this.RvA.contains("L") && this.RvA.contains("C") && (!this.RvA.contains("P"))) return false;
		// in RvB
		if (this.RvB.contains("L") && this.RvB.contains("C") && (!this.RvB.contains("P"))) return false;
		
		// check if C & H are in same place without P
		// in RvA
		if (this.RvA.contains("C") && this.RvA.contains("H") && (!this.RvA.contains("P"))) return false;
		// in RvB
		if (this.RvB.contains("C") && this.RvB.contains("H") && (!this.RvB.contains("P"))) return false;
		
		//else
		return true;
	}

	
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		state ex1State = (state) o;
		if (this.RvA.length() != ex1State.RvA.length()) return false;
		if (this.RvB.length() != ex1State.RvB.length()) return false;

		for (String ch : this.RvA.split("")) {
			if (!ex1State.RvA.contains(ch)) {return false;}
		}
		for (String ch : this.RvB.split("")) {
			if (!ex1State.RvB.contains(ch)) {return false;}
		}
		
		return true;
	}
	
	
	@Override
	public int hashCode() {
		return Objects.hash(RvA, RvB);
	}
	
	@Override
	public String toString() {
		return "le chemin est :[RvA:%s, RvB:%s]".formatted(RvA, RvB);
	}
	
}
