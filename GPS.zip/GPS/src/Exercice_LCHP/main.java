/**
 *
 */
/**
 * @author MOUHIHA MOHAMED
 *
 */
package Exercice_LCHP;

import GPS.Noeuds;

import java.util.ArrayList;

import GPS.*;

public class main {

    public static void main(String[] args) {
        //P-> payson
        //C-> chevre
        //H->  Chou
        //L-> loup

       state initState = new state("PLCH", "");
        ArrayList<action> actions = new ArrayList<>();

        actions.add(new action(1, "P<-"));
        // deplacer farmer + loup from A to B
        actions.add(new action(1, "PL->"));
        // deplacer farmer + loup from B to A
        actions.add(new action(1, "PL<-"));
        // deplacer farmer + chevre  from A to B
        actions.add(new action(1, "PC->"));
        // deplacer farmer + chevre from B to A
        actions.add(new action(1, "PC<-"));
        // deplacer farmer + chou  from A to B
        actions.add(new action(1, "PH->"));
        // deplacer farmer + chou  B to A
        actions.add(new action(1, "PH<-"));

// instance of probleme class with initial state and possile actions
        Problem problem = new Problem(initState, actions);
        // BFS helpper is a class that resume que achque fois en declare path ....
        Helper helper = new BFSalgorithm(problem);
        Noeuds noeuds = helper.Helpper();



        System.out.println((noeuds != null ? Problem.solution(noeuds) + " Cout: " + noeuds.getPathCost() + " " : "Vide"));



    }

}
